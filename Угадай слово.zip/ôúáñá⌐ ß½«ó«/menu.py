import tkinter as tk
from tkinter import ttk
from tkinter import messagebox  # Импортируем модуль для диалоговых окон
import subprocess
import os

def play_game():
    # Запускаем игру (main.py)
    game_process = subprocess.Popen(["python", "main.py"])
    game_process.wait()  # Ожидаем завершения игры
    # После завершения игры, снова отображаем меню
    root.deiconify()

def exit_game():
    # Запрашиваем подтверждение выхода
    result = messagebox.askyesno("Выход", "Вы действительно хотите выйти?")
    if result:
        # Закрываем окно приложения
        root.quit()

# Создаем главное окно
root = tk.Tk()
root.title("Меню игры")
root.geometry("400x300")
root.configure(bg="black")  # Установка черного фона

# Создаем стиль для кнопок
button_style = ttk.Style()
button_style.configure("GameButton.TButton",
                       font=("Arial", 20),
                       background="black",
                       foreground="green",
                       padding=20)

# Создаем кнопку "Play" и привязываем к ней функцию play_game
play_button = ttk.Button(root, text="Play", style="GameButton.TButton", command=play_game)
play_button.pack(pady=20, padx=20, side="left")

# Создаем кнопку "Exit" и привязываем к ней функцию exit_game
exit_button = ttk.Button(root, text="Exit", style="GameButton.TButton", command=exit_game)
exit_button.pack(pady=20, padx=20, side="left")

# Запускаем главный цикл Tkinter
root.mainloop()
