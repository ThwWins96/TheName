import pygame
import random

# Ініціалізація Pygame
pygame.init()

# Параметри вікна
WIDTH, HEIGHT = 800, 600
WINDOW_SIZE = (WIDTH, HEIGHT)
WINDOW_TITLE = "Вгадай слово"

# кольори
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
RED = (255, 0, 0)

# Фон
BG_COLOR = WHITE

# Шрифт
FONT_SIZE = 70
font = pygame.font.Font(None, FONT_SIZE)

# Загадані слова
WORDS = ["logika", "minecraft", "roblox", "marvel"]

# Вибір випадкового слова
word_to_guess = random.choice(WORDS)

# Кількість допустимих помилок
MAX_ERRORS = 5

# Стан гри
guessed_letters = []
errors = 0
game_over = False

# Основний цикл гри
screen = pygame.display.set_mode(WINDOW_SIZE)
pygame.display.set_caption(WINDOW_TITLE)

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN and not game_over:
            if event.key >= pygame.K_a and event.key <= pygame.K_z:
                letter = chr(event.key)
                if letter not in guessed_letters:
                    guessed_letters.append(letter)
                    if letter not in word_to_guess:
                        errors += 1

    screen.fill(BG_COLOR)

    word_display = ""
    for letter in word_to_guess:
        if letter in guessed_letters:
            word_display += letter
        else:
            word_display += "_"

    text = font.render(word_display, True, BLACK)
    screen.blit(text, (WIDTH // 2 - text.get_width() // 2, 450))

    # Відображення введених букв
    guessed_text = ', '.join(guessed_letters)
    guessed_text_surface = font.render("Введені букви: " + guessed_text, True, BLACK)
    screen.blit(guessed_text_surface, (10, 10))

    # Відображення кількості залишихся спроб
    remaining_attempts = MAX_ERRORS - errors
    attempts_text = font.render(f"Залишилось спроб: {remaining_attempts}", True, BLACK)
    screen.blit(attempts_text, (10, 50))

    if errors >= MAX_ERRORS:
        # Поразка: повністю червоний екран і відображення загаданого слова
        screen.fill(RED)
        defeat_text = font.render("Поразка!", True, BLACK)
        word_text = font.render("Загадане слово: " + word_to_guess, True, BLACK)
        screen.blit(defeat_text, (WIDTH // 2 - defeat_text.get_width() // 2, 250))
        screen.blit(word_text, (WIDTH // 2 - word_text.get_width() // 2, 300))
        game_over = True

    elif "_" not in word_display:
        # Перемога: повністю зелений екран і відображення загаданого слова
        screen.fill(GREEN)
        victory_text = font.render("Перемога!", True, BLACK)
        word_text = font.render("Загадане слово: " + word_to_guess, True, BLACK)
        screen.blit(victory_text, (WIDTH // 2 - victory_text.get_width() // 2, 250))
        screen.blit(word_text, (WIDTH // 2 - word_text.get_width() // 2, 300))
        game_over = True

    pygame.display.update()

pygame.quit()
